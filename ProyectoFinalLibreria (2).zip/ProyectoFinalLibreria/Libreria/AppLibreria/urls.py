from django.urls import path
from AppLibreria.views import *
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path("", inicio, name="Inicio"),
    path("libros/", libro, name="Libros"),
    path("filtros/", filtros, name="filtros"),
    path("contacto/", contacto, name="Contacto"),
    path("busquedaLibros/", busquedaLibros, name="BuscarLibros"),
    path("login/", inicioSesion, name="Login"),
    path("registro/", registro, name="SignUp"),
    path(
        "logout/",
        LogoutView.as_view(template_name="AppLibreria/logout.html"),
        name="Logout",
    ),
    path("libro/<int:libro_id>/", librodetalles, name="librodetalles"),
    path("aboutme/", aboutme, name="Aboutme"),
    # path("resultados/", resultados, name="ResultadosBusqueda"),
    # crud libros
]

