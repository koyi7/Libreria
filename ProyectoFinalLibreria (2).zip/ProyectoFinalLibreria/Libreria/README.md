# Proyecto final Coder House - Python
### Comisión: 47765
### Alumno: David Fonseca

# Proyecto

Libreria virtual

# Descripción del Proyecto

Quise hacer una página web donde se puedan comprar libros virtuales 
y dejar reseñas de los mismos.

No puse com requisito obligatorio que se registraran para poder ver la información percé de la página

Los usuario que entren a la web podrán
- dejar sus reseñas de los libros
- buscar los libros que necesiten y que se hayan cargado en la web

# Lenguaje usado

#### fron-end
- html 5
- Bootstrap 

#### Back-end

- Python 3
- Django 

# Dejo por acá el link del github

https://github.com/koyi7/Libreria.git