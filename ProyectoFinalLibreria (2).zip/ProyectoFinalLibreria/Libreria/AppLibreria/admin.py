from django.contrib import admin
from AppLibreria.models import *

# Register your models here.

admin.site.register(Libro)
admin.site.register(Categoria)
admin.site.register(ContactoModelo)
