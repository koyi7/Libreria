from django.shortcuts import render, get_object_or_404
from AppLibreria.forms import Contacto, UsuarioRegistro, ComentarioForm
from AppLibreria.models import ContactoModelo, Categoria, Libro, ComentarioModelo
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.views.generic import DetailView

# Create your views here.

#Retorno de HTML
def inicio(request):
    return render(request, "AppLibreria/inicio.html")

#Registro
def registro(request):
    if request.method == "POST":
        form = UsuarioRegistro(request.POST)

        if form.is_valid():
            username = form.cleaned_data["username"]
            form.save()
            return render(
                request, "AppLibreria/inicio.html", {"mensaje": "Usuario creado."}
            )

    else:
        form = UsuarioRegistro()

    return render(request, "AppLibreria/registro.html", {"formulario": form})
#Inicio de Sesión

def inicioSesion(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)

        if form.is_valid():
            usuario = form.cleaned_data.get("username")
            contra = form.cleaned_data.get("password")

            user = authenticate(username=usuario, password=contra)

            if user:
                login(request, user)  # acá el profesor colocó login(request, user)

                return render(
                    request,
                    "AppLibreria/inicio.html",
                    {"mensaje": f"Bienvenido a librosBuenardospuntoCom{user}"},
                )

        else:
            return render(
                request, "AppLibreria/login.html", {"mensaje": "Datos Incorrectos", "formulario":form}
            )

    else:
        form = AuthenticationForm()

    return render(request, "AppLibreria/login.html", {"formulario": form})

#Sección de Libros

def libro(request):
    categorias = Categoria.objects.all()

    if request.GET.get("libros", False) and request.GET.get("categoria", False):
        librosview = Libro.objects.filter(
            nombre__icontains=request.GET["libros"],
            categoria_id=request.GET["categoria"],
        )
    elif request.GET.get("libros", False):
        librosview = Libro.objects.filter(nombre__icontains=request.GET["libros"])

    elif request.GET.get("categoria", False):
        librosview = Libro.objects.filter(categoria_id=request.GET["categoria"])

    else:
        librosview = Libro.objects.all()

    for libro in librosview:
        libro.descripcion = (
            (libro.descripcion[:75] + "..")
            if len(libro.descripcion) > 75
            else libro.descripcion
        )

    contex = {"Libros": librosview, "Categorias": categorias}

    return render(request, "AppLibreria/libros.html", contex)


def detalles(request, libro_id):
    detalleslibro = Libro.objects.get(id=libro_id)

    contexto = {"libro": detalleslibro}

    return render(request, "AppLibreria/librodetalles.html", contexto)


def filtros(request):
    categorias = Categoria.objects.all()
    return render(request, "AppLibreria/filtros.html", {"categorias": categorias})

def busquedaLibros(request):
    return render(request, "AppLibreria/inicio.html")


def aboutme(request):
    return render(request, "AppLibreria/aboutme.html")

def contacto(request):
    if request.method == "POST":
        formulario = Contacto(request.POST)

        if formulario.is_valid():
            info = formulario.cleaned_data

            contactoModelo = ContactoModelo(
                nombre=info["first_name"],
                apellido=info["last_name"],
            )

            contactoModelo.save()

            return render(request, "AppLibreria/inicio.html")

    else:
        formulario = Contacto()

    return render(request, "AppLibreria/formulario.html", {"form1": formulario})


#Detalles y comentarios
def librodetalles(request, libro_id):
    libro = get_object_or_404(Libro, pk=libro_id)
    comentarios = ComentarioModelo.objects.filter(libro=libro)
    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            comentario = form.save(commit=False)
            comentario.libro = libro  
            comentario.save()
    else:
        form = ComentarioForm()
    return render(request, 'AppLibreria/librodetalles.html', {'libro': libro, 'comentarios': comentarios, 'form': form})


#class LibroDetailView(DetailView):
    model = Libro
    template_name = "AppLibreria/librodetalles.html"
    context_object_name = "libro"
    
#def comentarios(request):
    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "AppLibreria/librodetalles.html")
    else:
        form = ComentarioForm()
    
    return render(request,'librodetalles.html', {'form':form})
